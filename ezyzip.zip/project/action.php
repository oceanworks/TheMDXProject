<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table query action</title>
</head>
<body>
    <h1>We are almost there</h1>
    <p>Wait for a moment</p>
    <?php 
        $username = $_POST["username"];
        $password = $_POST["password"];
        $email = $_POST["email"];
        $xml = new DomDocument("1.0","UTF-8");
        $xml -> load("userdata.xml");
        $body_tag = $xml->getElementsByTagName("userdata")->item(0);
            $user_tag = $xml->createElement("user");
                $username_tag = $xml->createElement("username",$username);
                $password_tag = $xml->createElement("password",$password);
                $email_tag = $xml->createElement("email",$email);
            $user_tag -> appendChild($username_tag);
            $user_tag -> appendChild($password_tag);
        $user_tag -> appendChild($email_tag);
        $body_tag -> appendChild($user_tag);
        $xml -> save("userdata.xml");
        ?>
        <meta http-equiv="refresh" content="0; url=index.html">
</body>
