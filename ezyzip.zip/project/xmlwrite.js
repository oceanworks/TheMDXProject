'use strict';
let tableUsers = document.getElementById('userdata');
fetch('userdata.xml')
    .then(function(res){
        return res.text();
    })
    .then(function(data){
        let parser = new DOMParser(),
            xmlData = parser.parseFromString(data,'text/xml'),
            userdata = xmlData.querySelectorAll('user');
    userdata.forEach(userXmlNode => {

                    let row = document.createElement('tr');

                    //username
                    let td = document.createElement('td');
                    td.innerText = userXmlNode.children[0].innerHTML;
                    row.appendChild(td);

                    //password
                    td = document.createElement('td');
                    td.innerText = userXmlNode.children[1].innerHTML;
                    row.appendChild(td);
                    
                    //email
                    td = document.createElement('td');
                    td.innerText = userXmlNode.children[2].innerHTML;
                    row.appendChild(td);
                    tableUsers.children[1].appendChild(row);
                });

            });